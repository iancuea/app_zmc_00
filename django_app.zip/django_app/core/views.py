from django.shortcuts import render, get_object_or_404
from .models import Camion, EstadoCamion, Mantencion


def camion_list(request):
    camiones = Camion.objects.all().order_by('patente')
    return render(request, 'core/camion_list.html', {
        'camiones': camiones
    })

def camion_detail(request, id_camion):
    camion = get_object_or_404(Camion, id_camion=id_camion)

    estado = EstadoCamion.objects.filter(camion_id=id_camion).first()

    mantenciones = Mantencion.objects.filter(camion_id=id_camion).order_by('-fecha_mantencion')

    return render(request, 'core/camion_detail.html', {
        'camion': camion,
        'estado': estado,
        'mantenciones': mantenciones,
    })