from django.db import models

# Create your models here.


class Empresa(models.Model):
    nombre = models.CharField(max_length=100)
    rut = models.CharField(max_length=20, unique=True)
    activa = models.BooleanField(default=True)
    creado_en = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.nombre


class Camion(models.Model):
    id_camion = models.AutoField(primary_key=True)
    patente = models.CharField(max_length=10, unique=True)
    patente_remolque = models.CharField(max_length=10, blank=True, null=True)
    vin = models.CharField(max_length=17, unique=True, blank=True, null=True)
    marca = models.CharField(max_length=50, blank=True, null=True)
    modelo = models.CharField(max_length=50, blank=True, null=True)
    anio = models.IntegerField(blank=True, null=True)

    tipo_camion = models.CharField(max_length=50)
    tipo_carga = models.CharField(max_length=30, blank=True, null=True)

    ROL_OPERATIVO_CHOICES = [
        ('TITULAR', 'Titular'),
        ('BACKUP', 'Backup'),
    ]
    rol_operativo = models.CharField(max_length=10, choices=ROL_OPERATIVO_CHOICES)

    capacidad_m3 = models.IntegerField()

    TALLER_CHOICES = [
        ('ZMC', 'ZMC'),
        ('KAUFMANN', 'Kaufmann'),
    ]
    taller_mantencion = models.CharField(max_length=10, choices=TALLER_CHOICES)

    activo = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'camiones'

    def km_restantes(self):
        ultima = self.mantenciones.order_by('-fecha_mantencion').first()
        if ultima and ultima.km_proxima_mantencion is not None:
            return ultima.km_proxima_mantencion - (ultima.km_mantencion or 0)
        return None

    def __str__(self):
        return self.patente

class Mantencion(models.Model):
    id_mantencion = models.AutoField(primary_key=True)

    camion = models.ForeignKey(
        Camion,
        on_delete=models.CASCADE,
        db_column='id_camion',
        related_name='mantenciones'
    )

    taller = models.CharField(max_length=10)
    fecha_mantencion = models.DateField()
    km_mantencion = models.IntegerField(blank=True, null=True)
    km_proxima_mantencion = models.IntegerField(blank=True, null=True)
    km_restantes = models.IntegerField(blank=True, null=True)
    dias_revision_tecnica = models.IntegerField(blank=True, null=True)
    observaciones = models.TextField(blank=True, null=True)
    fecha_creacion = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'mantenciones'

    def __str__(self):
        return f"{self.camion.patente} - {self.fecha_mantencion}"
    
class EstadoCamion(models.Model):
    id_estado = models.AutoField(primary_key=True)

    camion = models.OneToOneField(
        Camion,
        on_delete=models.CASCADE,
        db_column='id_camion',
        related_name='estado_actual'
    )

    kilometraje = models.IntegerField()
    estado_operativo = models.CharField(max_length=20)
    observacion = models.TextField(blank=True, null=True)
    fecha_actualizacion = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'estado_camion'

    def __str__(self):
        return f"{self.camion.patente} - {self.estado_operativo}"

class HistorialEstadoCamion(models.Model):
    id_historial = models.AutoField(primary_key=True)

    camion = models.ForeignKey(
        Camion,
        on_delete=models.CASCADE,
        db_column='id_camion',
        related_name='historial_estados'
    )

    kilometraje = models.IntegerField(blank=True, null=True)
    estado_operativo = models.CharField(max_length=20)
    id_conductor = models.IntegerField(blank=True, null=True)
    descripcion_evento = models.TextField(blank=True, null=True)
    fecha_evento = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'historial_estado_camion'

    def __str__(self):
        return f"{self.camion.patente} - {self.estado_operativo}"

class DocumentoMantencion(models.Model):
    id_documento = models.AutoField(primary_key=True)

    mantencion = models.ForeignKey(
        Mantencion,
        on_delete=models.CASCADE,
        db_column='id_mantencion',
        related_name='documentos'
    )

    nombre_archivo = models.CharField(max_length=255)
    ruta_archivo = models.TextField()
    tipo_documento = models.CharField(max_length=50, blank=True, null=True)
    fecha_subida = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'documentos_mantencion'

    def __str__(self):
        return self.nombre_archivo
