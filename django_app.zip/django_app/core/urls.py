from django.urls import path
from . import views

urlpatterns = [
    path('camiones/', views.camion_list, name='camion_list'),
    path('camiones/<int:id_camion>/', views.camion_detail, name='camion_detail'),
]